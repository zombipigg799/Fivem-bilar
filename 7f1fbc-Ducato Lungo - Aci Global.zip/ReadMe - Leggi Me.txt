---------------------------------------------------------
Installation/Installa:

Put the files in this folder / Metti i file in questa cartella: 
GTAV/Mods>Update>x64>Dlcpacks>Patchday17>dlc.rpf>x64>Levels>Gta5>Vehicles.rpf

File ELS: Grand Theft Auto V\ELS\pack_default

ADD-On


Rilascia la cartella ducatoacip in mods \ update \ x64 \ dlcpacks
Modifica dlclist.xml da update \ update.rpf \ common \ data
aggiungi questa linea


<Item> dlcpacks: \ ducatoacip \ </ item>


Salvalo e sostituiscilo.

Nome di Spawn: ducatoacip


---------------------------------------------------------
Credits: 

Model: HUM3D
Converted by: RGP MODELS
Skinned by: RGP MODELS
Modded by: RGP MODELS
---------------------------------------------------------
"ATTENZIONE"

Non sei autorizzato a modificare la livrea - modello senza la mia autorizzazione, 
per informazioni scrivimi in privato
---------------------------------------------------------
"ATTENTION"

you are not allowed to modify my liveries - model without my authorization.
For information ask on private
---------------------------------------------------------
[ITA]

Se apprezzi i miei lavori passa sul mio canale Instagram e lasciami un follow, grazie!!

[ENG]

If you appreciate my works go on my Instagram channel and leave me a follow, thanks !!

---------------------------------------------------------
"Per novità su nuovi modelli entra nel nostro discord!"

https://discord.gg/ezePVMg
